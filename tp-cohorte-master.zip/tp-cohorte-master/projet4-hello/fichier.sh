#!/bin/bash
# Mettre les permissions d'execution sur ce fichier avant tout
echo "Hello, World!"

#!/bin/bash

curl http://www.google.com -o /home/ec2-user/google_sortie.txt

<?php
    // Ecrit le log dans mon fichier
    error_log("JUNIOR MEME ; TP DU SERVEUR PHP : ENTRER DANS LE HELP...");

?>

<!DOCTYPE html>
<html>
<head>
    <title>Mon site web</title>
    <style>
        body {
            background-color: black;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            color: white;
            font-family: Arial, sans-serif;
        }

        .card {
            background-color: #222;
            padding: 20px;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="card">
        <h1>Enregistrement du log</h1>
    </div>
</body>

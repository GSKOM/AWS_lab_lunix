<!DOCTYPE html>
<html>
<head>
    <title>Mon site web</title>
    <style>
        body {
            background-color: black;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            color: white;
            font-family: Arial, sans-serif;
        }

        .card {
            background-color: #222;
            padding: 20px;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="card">
        <h1>Bienvenue au home de PHP</h1>
    </div>
</body>
</html>
